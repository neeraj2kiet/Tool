package jaxbclasses;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
public class DifferenceOfXMLFiles {
	public static ManagedObjectType managedobject;
	public CmDataType cmdatatype;
	public static PType ptype;
	public static ListType listtype;
	public static ItemType itemtype;
	public static Workbook workbook;
	private static int rowNum=0;
	private static int colNum=0;
	private static Sheet sheet;
	private static Set<String> sheetpresents;
    private static CellStyle style;
    private static Set<String> headerset;
    private static HashMap<String,Integer> hmhead;
    private static Row row ;
    private static String excelfilename;
    private static String sheetcheckname;
    private static int rowchangecount;
    private static LinkedHashMap first;
    private static LinkedHashMap second;
    private static ArrayList<String> arlfirst;
    private static ArrayList<String> arlsecond;
    private static String sheetname;
    private static  Properties p;
    private static String keyname;
    static Logger log = Logger.getLogger(DifferenceOfXMLFiles.class.getName());
	
	
	public static void differencexmlsmethod(String filename1,String filename2,String excel) {
		 log.info("Executing differencexmlsmethod ... started ");
    int workbookcreated=5;
	 try {	
		 if(workbookcreated==5) {
		    createworkbook();
		 }
	
		sheetpresents=new HashSet<String>();
		//File file = new File("Configuration_scf_MRBTS-372640_RS0372640_20200908-1505.xml");
//		if(args.length!=2) {
//			System.out.println("Please execute the code with first xml file as input then the xlsx file like below");
//			System.out.println("java -jar configurationaudittool.jar xmlfilename.xml xlsxfilename.xlsx");
//			return;
//		}
		
	//	File file = new File(args[0]);
		File file = new File(filename1);
		File file2 = new File(filename2);
		try {
		 FileReader reader=new FileReader("uniquename.properties");  
		    p=new Properties();  
		    p.load(reader);  
		 //   System.out.println(p);
		      
		 //   System.out.println(p.getProperty("firstname"));  
		  //  System.out.println(p.getProperty("lastname"));  
		}catch(FileNotFoundException e) {
			log.warn(e);
		}catch(IOException e) {
			log.warn(e);
		}
		
		excelfilename=excel;
		
		//excelfilename="ABCDWITHDIFFERENTXML.xlsx";
		JAXBContext jaxbContext = JAXBContext.newInstance(RamlType.class);
		JAXBContext jaxbContext2 = JAXBContext.newInstance(RamlType.class);
		 
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		Unmarshaller jaxbUnmarshaller2 = jaxbContext.createUnmarshaller();
			
		 JAXBIntrospector ji1 = jaxbContext.createJAXBIntrospector();
		 JAXBIntrospector ji2 = jaxbContext.createJAXBIntrospector();
		 RamlType que = ( RamlType) ji1.getValue(jaxbUnmarshaller.unmarshal(file));
		 RamlType que2 = ( RamlType) ji2.getValue(jaxbUnmarshaller.unmarshal(file2));
		 List<ManagedObjectType> mo=que.getCmData().managedObject;
		 List<ManagedObjectType> mo2=que2.getCmData().managedObject;
		 ArrayList<ManagedObjectType> mocombined= new ArrayList<ManagedObjectType>();
		 mocombined.addAll(mo);
		 mocombined.addAll(mo2);
		 
		// System.out.println(mocombined.size());
		 
		 for(int z=0;z<mocombined.size();z++ ) {
			 rowchangecount=0;
			 String tempmo=mocombined.get(z).clazz.split("[:]")[1];
			// colNum=0;
			
			 List<ManagedObjectType> GroupMoList=new ArrayList<ManagedObjectType>();
			 List<ManagedObjectType> GroupMoList1=new ArrayList<ManagedObjectType>();
			 List<ManagedObjectType> GroupMoListWithLnCell=new ArrayList<ManagedObjectType>();
			
			 int groupmo=0;
			 for(groupmo=z;groupmo<mocombined.size();groupmo++) {
				
				 managedobject=mocombined.get(z);
				 sheetcheckname=managedobject.clazz.split("[:]")[1];
				// GroupMoList.add(mocombined.get(groupmo));
				
			//	System.out.println(sheetcheckname);
			   
				 
				 if(tempmo.equals(mocombined.get(groupmo).clazz.split("[:]")[1])) {
//					boolean lncel = mocombined.get(groupmo).distName.contains("LNCEL");
//					  if(lncel) {
				      GroupMoList.add(mocombined.get(groupmo));
				 // }
					
				 }
				
				 
			 }
			// System.out.println(GroupMoList);
			 for(int count=0;count<mo.size();count++) {
				 if(tempmo.equals(mocombined.get(count).clazz.split("[:]")[1])) {
				// boolean lncel = mo.get(count).distName.contains("LNCEL");
				//  if(lncel) {
			         GroupMoList1.add(mo.get(count));
				//  }
				 }
			 }
					 
			 rowchangecount=GroupMoList1.size();
			 int totallines=GroupMoList.size();
		
		//	 ArrayList lncellist=new ArrayList();
			 first=new LinkedHashMap();
			 second=new LinkedHashMap();
			 arlfirst=new ArrayList();
			 arlsecond=new ArrayList();
			 if(!sheetpresents.contains(sheetcheckname)) {
				 
			 for(int i=0;i<GroupMoList.size();i++) {
			    managedobject=GroupMoList.get(i);
			    
			 
			// for(int a=0;a<mocombined.size();a++) {
			//	 colNum=0;
				 
				 sheetname=managedobject.clazz.split("[:]")[1];
				// System.out.println(sheetname);
				 if(workbookcreated==5) {
			        createTab(sheetname);	
				 }
				// System.out.println(managedobject.distName);
				 
				 String [] distname=managedobject.distName.replace("-", ":").split("[/]");
				// System.out.println(distname);
				// List<String> distnamelist = Arrays.asList(distname);   
				 ArrayList<String> distnamelist= new ArrayList<String>(Arrays.asList(distname));
			//	 System.out.println(distnamelist);
				
				 //new code
				 List<JAXBElement> jaxbelementlist=managedobject.getContent();
				  for(int j=0;j<jaxbelementlist.size();j++) {
				   Object jaxbelement=jaxbelementlist.get(j);
				//  listtype=jaxbelementlist.get(j);
				  
//				  if(jaxbelement instanceof ListType) {
//					  System.out.println(jaxbelement1);
//				  }
				  
				  
				  if(jaxbelement instanceof JAXBElement) {
					  String ptagvalue="";
					  
					  if(jaxbelementlist.get(j).getValue() instanceof PType) {
						  ptype=(PType)jaxbelementlist.get(j).getValue();
						//  ptagvalue=ptype.name + "-" + ptype.value;
						  String name=ptype.name;
						  String value=ptype.value;
						//  System.out.println(name);
						  
						//  System.out.println(value);
						  ptagvalue=name + ":" + value;
//						  String[] arr = new String [20];
//						  arr[0]=ptagvalue;
//						  System.out.println(arr[0]);
						  
						  distnamelist.add(ptagvalue);
					//	  System.out.println(distnamelist);
				    	 }
				    	 
					  
				     // System.out.println(unwrap(jaxbelementlist.get(j)).toString()); 
					//  System.out.println(jaxbelementlist.get(j).getValue());
					  ptagvalue=(jaxbelementlist.get(j).getValue().toString());
					 // PTYpe pt=(PType)jaxbelementlist.get(j).getValue();
					// String [] arr= {};
					// arr[0]=(ptagvalue);
					//  System.out.println(arr[0]);
					
				    // Object ss=jaxbelementlist.get(j);
				     if(jaxbelementlist.get(j).getValue() instanceof ListType) {
				    	 String listsvalueofhead="";
				    	 String itemssvalues="";
				    	 String fullvalue="";
				    	 listtype=(ListType)jaxbelementlist.get(j).getValue();
				    	 listsvalueofhead=listtype + ":";
				    	// System.out.println(listtype.p);
				    	 
				    	// System.out.println(listsvalueofhead);
				    	 
				    	// ListType listtype1=(ListType)jaxbelementlist.get(j).getValue();
				    	 List<ItemType> item2= listtype.item;
				    	// System.out.println("Item " + item2);
				    	 //code to get item name value
				    	 for(int l=0;item2!=null && l<item2.size();l++) {
				    		 if(item2.get(l) instanceof ItemType) {
				    		// System.out.println("what is in p " + item2.get(l).p);
				    		 List<PType> lit=item2.get(l).p;
				    		// System.out.println("Lit " + lit);
				    		 for(int n=0;n<lit.size();n++) {
				    			 String tmp=lit.get(n).toString().replace("-", "=");
				    			 if(n!=lit.size()-1) {
				    			    itemssvalues= itemssvalues + tmp + "|";
				    			 }else {
				    				 itemssvalues= itemssvalues + tmp;
				    			 }
				    			
				    		 }
				    		// System.out.println("I need this" +  itemssvalues);
				    		 fullvalue=listsvalueofhead  +  itemssvalues;
				    		// System.out.println("I need this" +  fullvalue);
				    		 distnamelist.add(fullvalue);
				    		 
				    	//	System.out.println(distnamelist);
				    		// listsvalue=listvalue + item2.get(l).p;
				    	
				    		
				    		 }
				    	 }
				    	 
				    //	 System.out.println(listtype);
				    	
//       		    	List<ItemType> ittype1= listtype.getItem();
//				    	for(int t=0;t<ittype1.size();t++) {
//				    		System.out.println(ittype1.get(t).getName());
//				    	}
				    	 
				    	 
//				    					    	
				    	 List<String> ittype=listtype.getP();
				    	 
				    //	 ItemType itp=new ItemType();
				    	// itp.getName();
//				    	 if(jaxbelementlist.get(j).getValue() instanceof ItemType) {
//				    	   itemtype=(ItemType)jaxbelementlist.get(j).getValue();
//				    	   System.out.println(itemtype.getName());
//				    	 
//				    	 }
				    	 
				    	//System.out.println("list type get item" +listtype.getItem().toString());
				    //	System.out.println("list type get name" + listtype.getName());
//				    	for(int k=0;k<ittype.size();k++) {
//				    	     System.out.println("list type " + ittype.get(k));
//				    		
//				    	
//				    	}
				    	//if(ittype.size()!=0) {
				    	
				    //	System.out.println(ittype);
				    //	}
				    	// System.out.println(jaxbelementlist.get(j));
				     }
				      
				  } 
				//}	
			 
		 }
				 //new code end
				// for(String temp: distname) {
					// String newhead=temp.split("[-]")[0];
				//	 HashMap<String,String> hm=new HashMap<String,String>();
				//	 hm.put(newtemp[0],newtemp[1]);
				  
//				  for(int lnc=0;lnc<distnamelist.size();lnc++) {
//				  if(distnamelist.get(lnc).split("[-]")[0].equals("LNCEL")) {
//		        		System.out.println(distnamelist.get(lnc) + " contains " + "LNCEL");
//		        	}
//					  System.out.println(distnamelist.get(lnc));
//					  }
				
						 if(workbookcreated==5) {
					        createCellHead(distnamelist,sheetname);
						 }
					
					// colNum=colNum + 1;
					// System.out.println("Writing details to xsls file..");
					// System.out.println(distname);			
						 String sheetnameinproperty=p.getProperty(sheetcheckname);
						 //keyname=sheetnameinproperty.split("[:]")[1];
						    keyname="";
							if(sheetnameinproperty!=null && sheetnameinproperty.split("[:]")[0].equals(sheetcheckname)) {
								keyname=sheetnameinproperty.split("[:]")[1];
							    log.info("Inside if condition to check property name " + sheetnameinproperty + "Keyname " + keyname);
								//System.out.println(sheetcheckname);
								//System.out.println(distnamelist);
								//log.info("Key name is " + keyname);
							}
					 if(workbookcreated==5) {
						 if(i<rowchangecount) {
							//Test
							
							        // log.info("Adding values in excel file for first xml file  ");
									 createCellValues(distnamelist,sheetname,"firstxmlfile");
								
					       //  createCellValues(distnamelist,sheetname,"firstxmlfile");
					         
						 }else {
							// second=new HashMap();
							    //   log.info("Adding values for second xml file  ");
									createCellValues(distnamelist,sheetname,"secondxmlfile");
								
							
						 }
						 
//						  System.out.println(first.size() + "   " + arlfirst.size());
//							 System.out.println(second.size() + "   " + arlsecond.size());
							
						 
						 //code to color
						
						 
					 }
		 }
			 if(first.size()==1 && second.size()==1) {
			 ArrayList firstitem=(ArrayList)(first.get(arlfirst.get(0)));
			 ArrayList seconditem=(ArrayList)(second.get(arlsecond.get(0)));

			 
			 compareonlyOneItem(arlfirst,firstitem,arlsecond,seconditem,sheetname);
				 
			
		 }else {
		//	System.out.println(first);
		//	System.out.println(second);
			 if(keyname!=null) {
			 for(int i=0;i<first.size();i++) {
				 ArrayList firstitem=(ArrayList)(first.get(arlfirst.get(i)));
				 for(int j=0;j<second.size();j++) {
					 ArrayList seconditem=(ArrayList)(second.get(arlsecond.get(j)));
					 compareMultipleItems(arlfirst.get(i),firstitem,arlsecond.get(j),seconditem,keyname);
					 
				 }
			 }
			 }
			
		 }
	 }
			 
			 }

		
			//1 System.out.println(managedobject.clazz);
			//2 System.out.println(managedobject.distName);
			 
			 
			//    createCellHead();
			 
		 try {
			 if(workbookcreated==5) {
			 closingWorkbook();
			 }
			 }catch(Exception e) {
			        e.printStackTrace();
		}
		 
			  } catch (JAXBException e) {
		e.printStackTrace();
	  }
 
	}
	
	public static void compareonlyOneItem(ArrayList<String> arlfirst,ArrayList<String> firstitem,ArrayList<String> arlsecond, ArrayList <String>seconditem,String sheetname){
		//if(firstitem.size()==seconditem.size()) {
			for(int i=0;i<firstitem.size();i++) {
				for(int j=i;j<seconditem.size();j++) {
				
				  //if(sheetname.equals("LNBTS")) {
					 
	             // if((i<seconditem.size() && i<firstitem.size()) && !((firstitem.get(i)).equals(seconditem.get(i)))) {
					if(firstitem.get(i).split("[:]")[0].equals(seconditem.get(j).split("[:]")[0])) {
						if(!firstitem.get(i).split("[:]")[1].equals(seconditem.get(j).split("[:]")[1])) {
							color(arlfirst.get(0).split("[-]")[0],i);
			            	color(arlsecond.get(0).split("[-]")[0],i);
						}
						
						
	            	
	        	}
	              }
				
	              
				//}
			}
		//}
		
	}
	
	
	public static void compareMultipleItems(String arlfirst,ArrayList<String> firstitem,String arlsecond,ArrayList<String> seconditem,String keyname) {
		log.info("Executing compareMultipleItems method  " + firstitem + " " + seconditem  + " " +   keyname );
		boolean keyexist=false;
		String [] keys=keyname.split("[-]");
		String firstkeysvalue="";
		String secondkeysvalue="";
		
		for(int k=0;k<keys.length;k++) {
			for(int i=0;i<firstitem.size();i++) {
				if(firstitem.get(i).contains(keys[k])) {
					firstkeysvalue=firstkeysvalue+firstitem.get(i);
				}
			}
		}
		for(int k=0;k<keys.length;k++) {
			for(int i=0;i<seconditem.size();i++) {
				if(seconditem.get(i).contains(keys[k])) {
					secondkeysvalue=secondkeysvalue+seconditem.get(i);
				}
			}
		}
		
		if(firstkeysvalue.equals(secondkeysvalue)) {
			for(int i=0;i<firstitem.size();i++) {
				for(int j=i;j<seconditem.size();j++) {
				
				  //if(sheetname.equals("LNBTS")) {
					 
	             // if((i<seconditem.size() && i<firstitem.size()) && !((firstitem.get(i)).equals(seconditem.get(i)))) {
					if(firstitem.get(i).split("[:]")[0].equals(seconditem.get(j).split("[:]")[0])) {
						if(!firstitem.get(i).split("[:]")[1].equals(seconditem.get(j).split("[:]")[1])) {
							color(arlfirst.split("[-]")[0],i);
			            	color(arlsecond.split("[-]")[0],i);
						}
						
						
	            	
	        	}
	              }
				
	              
				//}
			}
		}
	}
	
	public static Object unwrap(Object o) {
		  if (o==null) return null;
		// System.out.println( ((JAXBElement)o).getDeclaredType().getSimpleName());
		  if (o instanceof javax.xml.bind.JAXBElement) {
		 // System.out.println("Unwrapped " + ((JAXBElement)o).getDeclaredType().getName() );
		  //System.out.println(("name: " + ((JAXBElement)o).getName() ));
		    return ((JAXBElement)o).getValue();
		  } else {
		    return o;
		  }
		  
}
	
public static void createworkbook() {
	   // log.info("Executing create workbook method ");
		workbook = new XSSFWorkbook();
		
		style = workbook.createCellStyle();
		Font boldFont = workbook.createFont();
	    boldFont.setBold(true);
	    style.setFont(boldFont);
	    style.setAlignment(CellStyle.ALIGN_CENTER);
		
	}
	

	
	public static void writeTOExcel() {
		
	}
    /**
     * Initializes the POI workbook and writes the header row
     */
	//Creating Different Tabs
	public static void createTab(String sheetname) {
		//Set<String> sheetpresents=new HashSet();
		
		if (workbook.getNumberOfSheets() != 0) {
			//System.out.println(sheetpresents);
			
		if(sheetpresents.contains(sheetname)) {
			//rowNum=rowNum + 1;
		//	System.out.println("Sheet is available " + sheetname );
			
		}else {
			sheet = workbook.createSheet(sheetname);
			rowNum=0;
		}
		}else {
			sheet = workbook.createSheet(sheetname);
			rowNum=0;
		}
			
	}
	
	public static void createCellHead(ArrayList<String> distname,String sheetname) {
		 //  log.info("creating header rows...." + distname + "  " + sheetname );
		//System.out.println("Create Head");
		    if(!sheetpresents.contains(sheetname)) {
		    headerset = new HashSet<String>();
		    hmhead=new HashMap();
		    colNum=0;
	        row = sheet.createRow(0);
	        for(int i=0;i<distname.size();i++) {
	        hmhead.put(distname.get(i).split("[:]")[0],colNum);
	        Cell cell = row.createCell(colNum++);
	        cell.setCellValue(distname.get(i).split("[:]")[0]);
			style.setRotation((short)90);
	        cell.setCellStyle(style);
	        headerset.add(distname.get(i).split("[:]")[0]);
	        }
	        sheetpresents.add(sheetname);
		    }else {
		    	 colNum=headerset.size();
		    	// Row row = sheet.createRow(0);
		    	 for(int i=0;i<distname.size();i++) {
		    	 
		         if(!headerset.contains(distname.get(i).split("[:]")[0])) {
		         hmhead.put(distname.get(i).split("[:]")[0],colNum);
		 	     Cell cell = row.createCell(colNum++);
		 	     cell.setCellValue(distname.get(i).split("[:]")[0]);
		 		 style.setRotation((short)90);
		 	     cell.setCellStyle(style);
		 	     headerset.add(distname.get(i).split("[:]")[0]);
		         }
		 	   }
		    	
		    }
		}
	
	public static void createCellValues(ArrayList<String> distname,String sheetname,String fileprocess) {
		boolean firstval=false;
		int tempcol=0;
		// log.info("Executing createCellvalues Method in Difference XMl classs " + distname + " " + " " + sheetname + " " + fileprocess);
		// System.out.println("adding data in excel....");
		    if(rowchangecount==rowNum) {
		    	rowNum=rowNum + 2;
		    	 Row row = sheet.createRow(rowNum);
		    	 Cell cell = row.createCell(1);
			     cell.setCellValue("Second XML DATA");
		    rowNum=rowNum + 2;
		    //second=new HashMap();
		   // second.put(rowNum,distname);
		 //   System.out.println("Second file "  + sheetname +   second);
		    }else {
		    	rowNum=rowNum + 1;
		    	// first=new HashMap();
				 //first.put(rowNum,distname);
				// System.out.println("First File " + sheetname +  first);
		    }
	        Row row = sheet.createRow(rowNum);
	      
	       
	        for(int i=0;i<distname.size();i++) {
	        colNum=hmhead.get(distname.get(i).split("[:]")[0]);
	        Cell cell = row.createCell(colNum);
	        cell.setCellValue(distname.get(i).split("[:]")[1]);
	      //  cell.setCellStyle(style);
//	        if(fileprocess.equals("firstxmlfile")) {
//	        	//  firstval=colNum + ":"+ firstval + "-" +   distname.get(i).split("[:]")[1];
//	        	arlfirst.add(rowNum+"-"+colNum + "-" + distname.get(i).split("[:]")[0]);
//	        	first.put(rowNum+"-"+colNum + "-" + distname.get(i).split("[:]")[0],distname.get(i).split("[:]")[1]);
////	        	 System.out.println(fileprocess + first);
////	        	 System.out.println(fileprocess + arlfirst);
//	        }
//	        if(fileprocess.equals("secondxmlfile")) {
//	        	arlsecond.add(rowNum+"-"+colNum + "-" + distname.get(i).split("[:]")[0]);
//	        	second.put(rowNum+"-"+colNum + "-" + distname.get(i).split("[:]")[0],distname.get(i).split("[:]")[1]);
//	        }
	        }
	        if(fileprocess.equals("firstxmlfile")) {
	        	//  firstval=colNum + ":"+ firstval + "-" +   distname.get(i).split("[:]")[1];
	        	arlfirst.add(rowNum+"-"+colNum);
	        	first.put(rowNum+"-"+colNum,distname);
//	        	 System.out.println(fileprocess + first);
//	        	 System.out.println(fileprocess + arlfirst);
	        }
	        if(fileprocess.equals("secondxmlfile")) {
	        	arlsecond.add(rowNum+"-"+colNum );
	        	second.put(rowNum+"-"+colNum,distname);
	        }
	       
	        	
	       
	     //   firstval=distname.get(i).split("[:]")[0].equals("LNCEL");
//	        if(firstval==true) {
//	        	tempcol=colNum;
//	        }
//	        if(fileprocess.equals("secondxmlfile") && distname.get(i).split("[:]")[0].equals("LNCEL")) {
//	        	tempcol=colNum;
//	        	
//	        
//	        }
//	        tempcol=colNum;
//	        if(fileprocess.equals("secondxmlfile") && tempcol>=2) {
//	               compare(first,tempcol,distname.get(i),rowNum);
//	        }
	        
	      //  }
	        
	       // sheet.createFreezePane(6,6);
	       
	       
			
           
	       	}
	
	public static void color(String str, int column){
		//  log.info("Executing color method ... ");
		Row row = sheet.getRow(Integer.parseInt(str));
			
		Cell cell = row.getCell((short) column );
		//cell.setCellValue(val);
        if(cell!=null) {
		CellStyle style = workbook.createCellStyle();
	//	style.setFillForegroundColor(IndexedColors.BLUE.getIndex());
		style.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
	    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
	    cell.setCellStyle(style);
        }
		
	}
	private static void compare(LinkedHashMap hmc,int colnum,String data,int rowNum) {
		Set firstfilesetkey=hmc.keySet();
	    Iterator it = firstfilesetkey.iterator();
	   // System.out.println(rowNum+"-"+colnum + " " + data);
		while (it.hasNext()) {
			// i=Integer.parseInt((String)(it.next()));
			 Object s=it.next();
		//   Map.Entry me2 = (Map.Entry) it.next();
			 ArrayList<Object> temparr=(ArrayList)hmc.get(s);
			 if(data.equals(temparr.get(2))) {
				 System.out.println(s + " " + rowNum + " " + colnum +  "   " + temparr);
				 return;
				
			 }else {
				 continue;
			 }
			    
	    }
		
	}
	
    public static void closingWorkbook() throws IOException {
    FileOutputStream fileOut = new FileOutputStream(excelfilename);
    workbook.write(fileOut);
    workbook.close();
    fileOut.close();
   log.info("Difference of xmls added in excel .. completed ");
   log.info("File " + excelfilename + " is generated Successfully...");
   
    }

}
