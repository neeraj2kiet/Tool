package jaxbclasses;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
public class GeneratingExcelFromXML {
	public static ManagedObjectType managedobject;
	public CmDataType cmdatatype;
	public static PType ptype;
	public static ListType listtype;
	public static ItemType itemtype;
	public static Workbook workbook;
	private static int rowNum=0;
	private static int colNum=0;
	private static Sheet sheet;
	private static Set<String> sheetpresents;
    private static CellStyle style;
    private static Set<String> headerset;
    private static HashMap<String,Integer> hmhead;
    private static Row row ;
    private static String excelfilename;
    private static String sheetcheckname;
    static Logger log = Logger.getLogger(DifferenceOfXMLFiles.class.getName());
	
	public static void generatexml(String filename,String excel) {
    int workbookcreated=5;
	 try {	
		 if(workbookcreated==5) {
		    createworkbook();
		 }
		sheetpresents=new HashSet<String>();
		//File file = new File("Configuration_scf_MRBTS-372640_RS0372640_20200908-1505.xml");
		
		
		File file = new File(filename);
		
		if(file==null) {
			log.info("Please Provide the xml file name as first input");
			return;
		}
		
		excelfilename=excel;
		if(excelfilename==null) {
			excelfilename="ConfigurationAuditTool.xlsx";
		}
		//excelfilename="ABCDWITHDIFFERENTXML.xlsx";
		JAXBContext jaxbContext = JAXBContext.newInstance(RamlType.class);
		 
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		// Source source = new StreamSource("target.xml");
		// JAXBElement<RamlType> root = jaxbUnmarshaller.unmarshal(source, RamlType.class);
		// RamlType que = root.getValue();
		 
		// System.out.println("=======================" + que);
	
		
		 JAXBIntrospector ji = jaxbContext.createJAXBIntrospector();
		 RamlType que = ( RamlType) ji.getValue(jaxbUnmarshaller.unmarshal(file));
		 List<ManagedObjectType> mo=que.getCmData().managedObject;
		 
		 for(int z=0;z<mo.size();z++ ) {
			 String tempmo=mo.get(z).clazz.split("[:]")[1];
			// colNum=0;
			
			 List<ManagedObjectType> GroupMoList=new ArrayList<ManagedObjectType>();
			 int groupmo=0;
			 for(groupmo=z;groupmo<mo.size();groupmo++) {
				
				 managedobject=mo.get(z);
				 sheetcheckname=managedobject.clazz.split("[:]")[1];
				// GroupMoList.add(mo.get(groupmo));
				
				 if(tempmo.equals(mo.get(groupmo).clazz.split("[:]")[1])) {
					// System.out.println("dfffdff");
					 GroupMoList.add(mo.get(groupmo));
					
				 }
				
				 
			 }
			 
			 GroupMoList.add(mo.get(z));
			 
			
		//	 System.out.println(GroupMoList.toString());
			 
//              for(int pp=0;pp<GroupMoList.size();pp++) {
//            	  System.out.println(GroupMoList.get(pp).clazz);
//			 }
			
			 if(!sheetpresents.contains(sheetcheckname)) {
			 for(int i=0;i<GroupMoList.size() -1;i++) {
			    managedobject=GroupMoList.get(i);
			 
			// for(int a=0;a<mo.size();a++) {
			//	 colNum=0;
				 
				 String sheetname=managedobject.clazz.split("[:]")[1];
				// System.out.println(sheetname);
				 if(workbookcreated==5) {
			        createTab(sheetname);	
				 }
				 String [] distname=managedobject.distName.replace("-", ":").split("[/]");
				// List<String> distnamelist = Arrays.asList(distname);   
				 ArrayList<String> distnamelist= new ArrayList<String>(Arrays.asList(distname));
				 //new code
				 List<JAXBElement> jaxbelementlist=managedobject.getContent();
				  for(int j=0;j<jaxbelementlist.size();j++) {
				   Object jaxbelement=jaxbelementlist.get(j);
				//  listtype=jaxbelementlist.get(j);
				  
//				  if(jaxbelement instanceof ListType) {
//					  System.out.println(jaxbelement1);
//				  }
				  
				  
				  if(jaxbelement instanceof JAXBElement) {
					  String ptagvalue="";
					  
					  if(jaxbelementlist.get(j).getValue() instanceof PType) {
						  ptype=(PType)jaxbelementlist.get(j).getValue();
						//  ptagvalue=ptype.name + "-" + ptype.value;
						  String name=ptype.name;
						  String value=ptype.value;
						//  System.out.println(name);
						  
						//  System.out.println(value);
						  ptagvalue=name + ":" + value;
//						  String[] arr = new String [20];
//						  arr[0]=ptagvalue;
//						  System.out.println(arr[0]);
						  
						  distnamelist.add(ptagvalue);
					//	  System.out.println(distnamelist);
				    	 }
				    	 
					  
				     // System.out.println(unwrap(jaxbelementlist.get(j)).toString()); 
					//  System.out.println(jaxbelementlist.get(j).getValue());
					  ptagvalue=(jaxbelementlist.get(j).getValue().toString());
					 // PTYpe pt=(PType)jaxbelementlist.get(j).getValue();
					// String [] arr= {};
					// arr[0]=(ptagvalue);
					//  System.out.println(arr[0]);
					
				    // Object ss=jaxbelementlist.get(j);
				     if(jaxbelementlist.get(j).getValue() instanceof ListType) {
				    	 String listsvalueofhead="";
				    	 String itemssvalues="";
				    	 String fullvalue="";
				    	 listtype=(ListType)jaxbelementlist.get(j).getValue();
				    	 listsvalueofhead=listtype + ":";
				    	// System.out.println(listtype.p);
				    	 
				    	// System.out.println(listsvalueofhead);
				    	 
				    	// ListType listtype1=(ListType)jaxbelementlist.get(j).getValue();
				    	 List<ItemType> item2= listtype.item;
				    	// System.out.println("Item " + item2);
				    	 //code to get item name value
				    	 for(int l=0;item2!=null && l<item2.size();l++) {
				    		 if(item2.get(l) instanceof ItemType) {
				    		// System.out.println("what is in p " + item2.get(l).p);
				    		 List<PType> lit=item2.get(l).p;
				    		// System.out.println("Lit " + lit);
				    		 for(int n=0;n<lit.size();n++) {
				    			 String tmp=lit.get(n).toString().replace("-", "=");
				    			 if(n!=lit.size()-1) {
				    			    itemssvalues= itemssvalues + tmp + "|";
				    			 }else {
				    				 itemssvalues= itemssvalues + tmp;
				    			 }
				    			
				    		 }
				    		// System.out.println("I need this" +  itemssvalues);
				    		 fullvalue=listsvalueofhead  +  itemssvalues;
				    		// System.out.println("I need this" +  fullvalue);
				    		 distnamelist.add(fullvalue);
				    		 
				    		// listsvalue=listvalue + item2.get(l).p;
				    		 }
				    	 }
				    	 
				    //	 System.out.println(listtype);
				    	
//       		    	List<ItemType> ittype1= listtype.getItem();
//				    	for(int t=0;t<ittype1.size();t++) {
//				    		System.out.println(ittype1.get(t).getName());
//				    	}
				    	 
				    	 
//				    					    	
				    	 List<String> ittype=listtype.getP();
				    	 
				    //	 ItemType itp=new ItemType();
				    	// itp.getName();
//				    	 if(jaxbelementlist.get(j).getValue() instanceof ItemType) {
//				    	   itemtype=(ItemType)jaxbelementlist.get(j).getValue();
//				    	   System.out.println(itemtype.getName());
//				    	 
//				    	 }
				    	 
				    	//System.out.println("list type get item" +listtype.getItem().toString());
				    //	System.out.println("list type get name" + listtype.getName());
//				    	for(int k=0;k<ittype.size();k++) {
//				    	     System.out.println("list type " + ittype.get(k));
//				    		
//				    	
//				    	}
				    	//if(ittype.size()!=0) {
				    	
				    //	System.out.println(ittype);
				    //	}
				    	// System.out.println(jaxbelementlist.get(j));
				     }
				      
				  } 
				//}	
			 
		 }
				 //new code end
				// for(String temp: distname) {
					// String newhead=temp.split("[-]")[0];
				//	 HashMap<String,String> hm=new HashMap<String,String>();
				//	 hm.put(newtemp[0],newtemp[1]);
					 
						 if(workbookcreated==5) {
					        createCellHead(distnamelist,sheetname);
						 }
					
					// colNum=colNum + 1;
					// System.out.println("Writing details to xsls file..");
					// System.out.println(distname);					 
					 if(workbookcreated==5) {
					 createCellValues(distnamelist);
					 }
		 }
	 }
			 }
			 
			 
			//1 System.out.println(managedobject.clazz);
			//2 System.out.println(managedobject.distName);
			 
			 
			//    createCellHead();
			 
		 try {
			 if(workbookcreated==5) {
			 closingWorkbook();
			 }
			 }catch(Exception e) {
			        e.printStackTrace();
		}
		 
			  } catch (JAXBException e) {
		e.printStackTrace();
	  }
 
	}
	public static Object unwrap(Object o) {
		  if (o==null) return null;
		// System.out.println( ((JAXBElement)o).getDeclaredType().getSimpleName());
		  if (o instanceof javax.xml.bind.JAXBElement) {
		 // System.out.println("Unwrapped " + ((JAXBElement)o).getDeclaredType().getName() );
		  //System.out.println(("name: " + ((JAXBElement)o).getName() ));
		    return ((JAXBElement)o).getValue();
		  } else {
		    return o;
		  }
		  
}
	
public static void createworkbook() {
		workbook = new XSSFWorkbook();
		
		style = workbook.createCellStyle();
		Font boldFont = workbook.createFont();
	    boldFont.setBold(true);
	    style.setFont(boldFont);
	    style.setAlignment(CellStyle.ALIGN_CENTER);
		
	}
	

	
	public static void writeTOExcel() {
		
	}
    /**
     * Initializes the POI workbook and writes the header row
     */
	//Creating Different Tabs
	public static void createTab(String sheetname) {
		//Set<String> sheetpresents=new HashSet();
		 log.info("Executing Createtab method in generatingExcel code ...");
		
		if (workbook.getNumberOfSheets() != 0) {
			//System.out.println(sheetpresents);
			
		if(sheetpresents.contains(sheetname)) {
			//rowNum=rowNum + 1;
		//	System.out.println("Sheet is available " + sheetname );
			
		}else {
			sheet = workbook.createSheet(sheetname);
			rowNum=0;
		}
		}else {
			sheet = workbook.createSheet(sheetname);
			rowNum=0;
		}
		
		
		
	}
	
	public static void createCellHead(ArrayList<String> distname,String sheetname) {
		    log.info("creating header rows.... in Generating Excel From XML code");
		    if(!sheetpresents.contains(sheetname)) {
		    headerset = new HashSet<String>();
		    hmhead=new HashMap();
		    colNum=0;
	        row = sheet.createRow(0);
	        for(int i=0;i<distname.size();i++) {
	        hmhead.put(distname.get(i).split("[:]")[0],colNum);
	        Cell cell = row.createCell(colNum++);
	        cell.setCellValue(distname.get(i).split("[:]")[0]);
			style.setRotation((short)90);
	        cell.setCellStyle(style);
	        headerset.add(distname.get(i).split("[:]")[0]);
	        }
	        sheetpresents.add(sheetname);
		    }else {
		    	 colNum=headerset.size();
		    	// Row row = sheet.createRow(0);
		    	 for(int i=0;i<distname.size();i++) {
		    	 
		         if(!headerset.contains(distname.get(i).split("[:]")[0])) {
		         hmhead.put(distname.get(i).split("[:]")[0],colNum);
		 	     Cell cell = row.createCell(colNum++);
		 	     cell.setCellValue(distname.get(i).split("[:]")[0]);
		 		 style.setRotation((short)90);
		 	     cell.setCellStyle(style);
		 	     headerset.add(distname.get(i).split("[:]")[0]);
		         }
		 	   }
		    	
		    }
		}
	
	public static void createCellValues(ArrayList<String> distname) {
		 log.info("adding data in excel....  in generatingExcel code ...");
		    rowNum=rowNum + 1;
	        Row row = sheet.createRow(rowNum);
	        for(int i=0;i<distname.size();i++) {
	        colNum=hmhead.get(distname.get(i).split("[:]")[0]);
	        Cell cell = row.createCell(colNum);
	        cell.setCellValue(distname.get(i).split("[:]")[1]);
	      //  cell.setCellStyle(style);
	        }
	        
	       // sheet.createFreezePane(6,6);

	       	}
	
    public static void closingWorkbook() throws IOException {
    FileOutputStream fileOut = new FileOutputStream(excelfilename);
    workbook.write(fileOut);
    workbook.close();
    fileOut.close();
    log.info("closing work book method executed... END");
    log.info("File " + excelfilename + " is generated Successfully"); 
    }

}
