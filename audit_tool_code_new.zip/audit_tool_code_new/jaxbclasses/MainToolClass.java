package jaxbclasses;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class MainToolClass {
	 static Logger log = Logger.getLogger(MainToolClass.class.getName());
	public static void main(String args[]) {
		PropertyConfigurator.configure("log4j.properties");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		log.info("===============Current Date============================ "  + sdf.format(cal.getTime()));
	//	log.info("Current Date: "+sdf.format(cal.getTime()));
		
		String excelfilename="";
		String filename1 = "";
		String filename2 = "";
		String filename="";
		if(args[0].equals("difference") && args.length==4) {
			
			log.info("Executing Code to take xml file difference " + sdf.format(cal.getTime()));
			excelfilename="";
		    filename1 = args[1];
			filename2 = args[2];
			
			if(filename1==null || filename1==null) {
				log.warn("Please Provide the xml files name as input to compare  ... difference");
				return;
			}
			int Dotxml1=args[1].split("[.]").length;
			int Dotxml2=args[2].split("[.]").length;
			if(Dotxml1==2) {
			String fileformat=args[1].split("[.]")[1];
			if(!fileformat.equals("xml")) {
				log.warn("Please Provide the xml file name as input");
				return;
				
			}
			}else if(Dotxml1==1) {
				log.warn("Please provide xml extension to the file...");
				return;
			}
			if(Dotxml2==2) {
				String fileformat=args[2].split("[.]")[1];
				if(!fileformat.equals("xml")) {
					log.warn("Please Provide the xml file name as input dotxml==2 and fileformat" + fileformat);
					return;
					
				}
				}else if(Dotxml2==1) {
					log.warn("Please provide xml extension to the file... dotxml2==1");
					return;
				}
			excelfilename=args[3];
			log.info(excelfilename);
			if(excelfilename==null) {
				excelfilename="ConfigurationDifference.xlsx";
			}
			DifferenceOfXMLFiles.differencexmlsmethod(filename1,filename2,excelfilename);
		}else if(args[0].equals("generate") && args.length==3) {
			 
				//File file = new File("Configuration_scf_MRBTS-372640_RS0372640_20200908-1505.xml");
			log.info("Executing Code to excel from xml " + sdf.format(cal.getTime()));
				if(args.length!=3) {
					log.warn("Please execute the code with first xml file as input then the xlsx file..");
					//System.out.println("java -jar configurationaudittool.jar xmlfilename.xml xlsxfilename.xlsx");
					return;
				}
				
				filename = args[1];
				
				if(filename==null) {
					log.warn("Please Provide the xml file name as first input");
					return;
				}
				int Dotxml=args[1].split("[.]").length;
				if(Dotxml==2) {
				String fileformat=args[1].split("[.]")[1];
				if(!fileformat.equals("xml")) {
					log.warn("Please Provide the xml file name as first input");
					return;
					
				}
				}else if(Dotxml==1) {
					log.warn("Please provide xml extension to the file... dotxml==1" );
					return;
				}
				excelfilename=args[2];
				
				GeneratingExcelFromXML.generatexml(filename, excelfilename);
			
		}else {
			log.warn("Please provid the inputs properly...." + args[0]);
			return;
		}
			
	}
}
